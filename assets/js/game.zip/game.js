let canvas = document.getElementById("gameZone");
let context = canvas.getContext("2d");
var i = 0;
canvas.width = canvas.clientWidth;
canvas.height = canvas.clientHeight;

const ceil = 50;
const width = canvas.width;
const height = canvas.height;
var status = "game";
let item = 0;
let count_img = 0;
let map = [];
let map_buffer = [];
let hero = {
    "x":0,
    "y":0,
    "hp":3,
     
}
var h = hero.hp;
let map_carrot = [{"x":100,"y":100,},{"x":300,"y":300},{"x":400,"y":200},]
let car = [{"x":100,"y":400,},{"x":400,"y":100},{"x":100,"y":200},]

let grass = new Image(ceil,ceil);
grass.src = "assets/img/fafad.png";
let bunny = new Image(ceil,ceil)
bunny.src = "assets/img/bunny.jpg"
let carrot = new Image(ceil,ceil);
carrot.src = "assets/img/carrot.jpg";
let spike = new Image(ceil,ceil);
spike.src = "assets/img/spike.png";
for (let i = 0; i < width/ceil; i++){
    for(let j = 0; j < height/ceil; j++){
        map.push({
            "x":i*ceil,
            "y":j*ceil       
        });
    }
}

document.addEventListener("keydown",function(event){
        let press_key = event.code;
        switch(press_key){
            case "KeyA":
                
                if(hero.x > 0){
                    hero.x -= ceil;
                }
                  
                break;
            case "KeyS":
                if(hero.y < width-ceil){
                hero.y += ceil;
                }
                break;
            case "KeyD":
                if(hero.x < height-ceil){
                        hero.x += ceil;
                }
                
                break;
            case "KeyW":
                if(hero.y > 0){
                        hero.y -= ceil;
                }
                
                break;
        }
});
canvas.addEventListener("mousedown",function(event){
    let x = Math.floor(event.offsetX/ceil);
    let y = Math.floor(event.offsetY/ceil);
    let sprite = new Image();
    let ceil_index = map.findIndex(item => item.x == x*ceil && item.y == y*ceil/*item.x >=x && item.x <= x && item.y >= y && item.y < */ )
    switch(item){
        case 1:
                sprite.src = "assets/img/bunny.jpg";
            break;
            case 2:
                sprite.src = "assets/img/carrot.jpg";
            break;
            case 3: 
            sprite.src = "assets/img/fafad.png" ;
            break;
            case 4:
                sprite.src = "assets/img/wal1.png";
            break;
            case 5:
                sprite.src = "assets/img/button.png";
            break;
            case 6:
                sprite.src ="assets/img/wal2.png";
            break;
            case 7:
                sprite.src = "assets/img/wal4.png";
            break;
            case 8:
                sprite.src = "assets/img/woodenfence1.jpg";
            break;
            case 9:
                sprite.src = "assets/img/trapp.png"
                break;
    }
    let repeat = map_buffer.findIndex(item => item.ceil == ceil_index)
    
    if(item == 1){
        let check = map_buffer.findIndex(map_item => map_item.item == item)
        if(check != -1){
            map_buffer.splice(check,1);
        }
    }
    if(repeat != -1){
        map_buffer.splice(repeat,1)
    }
    map_buffer.push({"ceil":ceil_index,"item":item,"count":count_img,"image":sprite});
    console.log(ceil_index);
});

function game(){
        for(let buffer_i = 0; buffer_i < map_buffer.length; buffer_i++){
        if(map_buffer[buffer_i].item != 1){
         context.drawImage(map_buffer[buffer_i].image,
            map[map_buffer[buffer_i].ceil].x,
            map[map_buffer[buffer_i].ceil].y,
            ceil,
            ceil)
        }
        else{
            context.drawImage(map_buffer[buffer_i].image,
                hero.x,
                hero.y,
                ceil,
                ceil)
        }
    let result_find = map_buffer.findIndex(item => map[item.ceil].x == hero.x && map[item.ceil].y == hero.y && item.item == 1);
    if(result_find != -1){
        map_carrot.splice(result_find,1);
    }

    if(status == "game"){
        requestAnimationFrame(game);
    }
}

    
}



function editor(){
    context.clearRect(0,0,width,height);
    for(let map_i = 0; map_i < map.length; map_i++){
        
        context.strokeRect(map[map_i].x,map[map_i].y,ceil,ceil); 
    }
    for(let buffer_i = 0; buffer_i < map_buffer.length; buffer_i++){
                context.drawImage(map_buffer[buffer_i].image,map[map_buffer[buffer_i].ceil].x,
                    map[map_buffer[buffer_i].ceil].y,
                    ceil,
                    ceil)
    }
    if(status == "edit"){
        requestAnimationFrame(editor);
}
    }
    